
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.endercraft.init;

import net.mcreator.endercraft.procedures.RawweedPlayerFinishesUsingItemProcedure;
import net.mcreator.endercraft.procedures.EightballItemInInventoryTickProcedure;
import net.mcreator.endercraft.procedures.CookedweedPlayerFinishesUsingItemProcedure;
import net.mcreator.endercraft.procedures.CoccainePlayerFinishesUsingItemProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class EndercraftModProcedures {
	public static void load() {
		new RawweedPlayerFinishesUsingItemProcedure();
		new CoccainePlayerFinishesUsingItemProcedure();
		new EightballItemInInventoryTickProcedure();
		new CookedweedPlayerFinishesUsingItemProcedure();
	}
}
