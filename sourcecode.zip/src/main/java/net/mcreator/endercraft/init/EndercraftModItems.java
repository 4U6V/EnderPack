
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.endercraft.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.endercraft.item.RawweedItem;
import net.mcreator.endercraft.item.ProcessedcocoabeansItem;
import net.mcreator.endercraft.item.EightballItem;
import net.mcreator.endercraft.item.CookedweedItem;
import net.mcreator.endercraft.item.CoccaineItem;
import net.mcreator.endercraft.EndercraftMod;

public class EndercraftModItems {
	public static Item COCCABEANBLOCK;
	public static Item PROCESSEDCOCOABEANS;
	public static Item COCCAINE;
	public static Item WEEDPLANT;
	public static Item RAWWEED;
	public static Item EIGHTBALL;
	public static Item COOKEDWEED;

	public static void load() {
		COCCABEANBLOCK = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "coccabeanblock"), new BlockItem(EndercraftModBlocks.COCCABEANBLOCK, new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
		PROCESSEDCOCOABEANS = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "processedcocoabeans"), new ProcessedcocoabeansItem());
		COCCAINE = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "coccaine"), new CoccaineItem());
		WEEDPLANT = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "weedplant"), new BlockItem(EndercraftModBlocks.WEEDPLANT, new Item.Properties().tab(CreativeModeTab.TAB_DECORATIONS)));
		RAWWEED = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "rawweed"), new RawweedItem());
		EIGHTBALL = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "eightball"), new EightballItem());
		COOKEDWEED = Registry.register(Registry.ITEM, new ResourceLocation(EndercraftMod.MODID, "cookedweed"), new CookedweedItem());
	}
}
