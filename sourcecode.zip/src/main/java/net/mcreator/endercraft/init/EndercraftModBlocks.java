
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.endercraft.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.endercraft.block.WeedplantBlock;
import net.mcreator.endercraft.block.CoccabeanblockBlock;
import net.mcreator.endercraft.EndercraftMod;

public class EndercraftModBlocks {
	public static Block COCCABEANBLOCK;
	public static Block WEEDPLANT;

	public static void load() {
		COCCABEANBLOCK = Registry.register(Registry.BLOCK, new ResourceLocation(EndercraftMod.MODID, "coccabeanblock"), new CoccabeanblockBlock());
		WEEDPLANT = Registry.register(Registry.BLOCK, new ResourceLocation(EndercraftMod.MODID, "weedplant"), new WeedplantBlock());
	}

	public static void clientLoad() {
		CoccabeanblockBlock.clientInit();
		WeedplantBlock.clientInit();
	}
}
