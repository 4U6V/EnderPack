/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package net.mcreator.endercraft;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.mcreator.endercraft.init.EndercraftModTabs;
import net.mcreator.endercraft.init.EndercraftModProcedures;
import net.mcreator.endercraft.init.EndercraftModItems;
import net.mcreator.endercraft.init.EndercraftModFeatures;
import net.mcreator.endercraft.init.EndercraftModBlocks;

import net.fabricmc.api.ModInitializer;

public class EndercraftMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final String MODID = "endercraft";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing EndercraftMod");
		EndercraftModTabs.load();

		EndercraftModBlocks.load();
		EndercraftModItems.load();

		EndercraftModFeatures.load();

		EndercraftModProcedures.load();

	}
}
